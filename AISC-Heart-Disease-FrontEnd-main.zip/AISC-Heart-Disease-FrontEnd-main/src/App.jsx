import './App.css'
import FirstPage from './FirstPageFolder/FirstPage.jsx'

function App() {
  return (
    <>
      <div>
            <FirstPage/>
        </div>
    </>
  );
}

export default App
